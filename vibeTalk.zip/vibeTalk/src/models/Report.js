const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
    reporter: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    reportedUser: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    reportedMessage: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Message'
    },
    reason: {
        type: String,
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'reviewed', 'resolved'],
        default: 'pending'
    },
    notes: {
        type: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Ensure either reportedUser or reportedMessage is provided
reportSchema.pre('save', function(next) {
    if (!this.reportedUser && !this.reportedMessage) {
        next(new Error('Either reportedUser or reportedMessage must be provided'));
    }
    if (this.reportedUser && this.reportedMessage) {
        next(new Error('Cannot report both user and message at the same time'));
    }
    next();
});

module.exports = mongoose.model('Report', reportSchema);