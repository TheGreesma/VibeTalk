const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
    content: {
        type: String,
        required: true
    },
    sender: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    recipient: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    group: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Group'
    },
    timestamp: {
        type: Date,
        default: Date.now
    },
    fileUrl: String,
    fileName: String,
    fileType: String
}, {
    timestamps: true
});

// Fix validation logic
messageSchema.pre('save', function(next) {
    if ((this.recipient && this.group) || (!this.recipient && !this.group)) {
        return next(new Error('Message must have either a recipient or a group, but not both'));
    }
    next();
});

// Index for faster queries
messageSchema.index({ sender: 1, recipient: 1 });
messageSchema.index({ group: 1 });  // Add index for group messages

module.exports = mongoose.model('Message', messageSchema);