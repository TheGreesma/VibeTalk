const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const fs = require('fs').promises;
const User = require('./models/User');
const Message = require('./models/Message');
const Group = require('./models/Group');
const auth = require('./middleware/auth'); // Add auth middleware import
require('dotenv').config();

const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const userRoutes = require('./routes/users');
const reportRoutes = require('./routes/reports'); // Add this line

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: async function (req, file, cb) {
        const uploadDir = path.join(__dirname, '../uploads');
        try {
            await fs.mkdir(uploadDir, { recursive: true });
            cb(null, uploadDir);
        } catch (error) {
            cb(error);
        }
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});

// Update file upload configuration
const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB limit
    },
    fileFilter: (req, file, cb) => {
        // Allow images and common document types
        const allowedTypes = [
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain'
        ];
        
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type'));
        }
    }
});

// Connect to MongoDB with debug logging
console.log('Attempting to connect to MongoDB...');
console.log('MongoDB URI:', process.env.MONGODB_URI.replace(/:([^:@]+)@/, ':****@')); // Hide password in logs

mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Successfully connected to MongoDB Atlas');
})
.catch(err => {
    console.error('MongoDB connection error details:', {
        message: err.message,
        code: err.code,
        codeName: err.codeName
    });
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
// Add static middleware for uploads directory
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Active users storage
const activeUsers = new Map(); // userId -> { socket, user }

// Move the group messages endpoint before the user messages endpoint to avoid route conflict
app.get('/api/group-messages/:groupId', auth, async (req, res) => {
    try {
        const group = await Group.findById(req.params.groupId);
        if (!group || !group.members.includes(req.user._id)) {
            return res.status(403).json({ error: 'Not authorized to access this group' });
        }

        const messages = await Message.find({
            group: req.params.groupId
        })
        .populate('sender', 'name email')
        .sort('timestamp');

        const formattedMessages = messages.map(msg => ({
            id: msg._id,
            content: msg.content,
            sender: {
                id: msg.sender._id.toString(),
                name: msg.sender.name
            },
            groupId: msg.group.toString(),
            timestamp: msg.timestamp,
            fileData: msg.fileUrl ? {
                url: msg.fileUrl,
                fileName: msg.fileName,
                type: msg.fileType
            } : null
        }));

        res.json(formattedMessages);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get chat history endpoint
app.get('/api/messages/:userId', async (req, res) => {
    try {
        const token = req.header('Authorization')?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ error: 'Authentication required' });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const messages = await Message.find({
            $or: [
                { sender: decoded.userId, recipient: req.params.userId },
                { sender: req.params.userId, recipient: decoded.userId }
            ]
        })
        .populate('sender', 'name email')
        .populate('recipient', 'name email')
        .sort('timestamp');

        // Transform messages to include proper sender/recipient info
        const formattedMessages = messages.map(msg => ({
            id: msg._id,
            content: msg.content,
            sender: {
                id: msg.sender._id.toString(), // Convert ObjectId to string
                name: msg.sender.name
            },
            recipient: {
                id: msg.recipient._id.toString(), // Convert ObjectId to string
                name: msg.recipient.name
            },
            timestamp: msg.timestamp,
            fileUrl: msg.fileUrl,
            fileName: msg.fileName,
            fileType: msg.fileType
        }));

        res.json(formattedMessages);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Add group message history endpoint
app.get('/api/messages/group/:groupId', auth, async (req, res) => {
    try {
        const group = await Group.findById(req.params.groupId);
        if (!group || !group.members.includes(req.user._id)) {
            return res.status(403).json({ error: 'Not authorized to access this group' });
        }

        const messages = await Message.find({
            group: req.params.groupId
        })
        .populate('sender', 'name email')
        .sort('timestamp');

        const formattedMessages = messages.map(msg => ({
            id: msg._id,
            content: msg.content,
            sender: {
                id: msg.sender._id.toString(),
                name: msg.sender.name
            },
            groupId: msg.group,
            timestamp: msg.timestamp,
            fileData: msg.fileUrl ? {
                url: msg.fileUrl,
                fileName: msg.fileName,
                type: msg.fileType
            } : null
        }));

        res.json(formattedMessages);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Add endpoint to get user online status
app.get('/api/users/status/:userId', auth, async (req, res) => {
    try {
        const requestedUser = await User.findById(req.params.userId).select('isOnline lastSeen');
        if (!requestedUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json({
            isOnline: requestedUser.isOnline,
            lastSeen: requestedUser.lastSeen
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Socket.IO Authentication Middleware
io.use(async (socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) {
        return next(new Error('Authentication error'));
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.userId).select('-password');
        if (!user) {
            return next(new Error('User not found'));
        }
        socket.userId = decoded.userId;
        socket.user = user;
        next();
    } catch (err) {
        next(new Error('Authentication error'));
    }
});

// Serve static files
app.use(express.static(path.join(__dirname, '../public')));
app.use('/uploads', express.static(path.join(__dirname, '../public/uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/users', userRoutes);
app.use('/api/reports', reportRoutes); 

// Serve static files
app.use(express.static(path.join(__dirname, '../public')));

// Route handlers for main pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/login.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/admin-login.html'));
});

// Update file upload endpoint
app.post('/api/upload', auth, upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        // Clean the filename to prevent XSS
        const sanitizedFileName = req.file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
        // Add forward slash at the beginning of the URL
        const fileUrl = `/uploads/${req.file.filename}`;

        res.json({ 
            fileUrl: fileUrl, // Return the URL with leading slash
            fileName: sanitizedFileName,
            type: req.file.mimetype
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Group Routes
app.post('/api/groups', auth, async (req, res) => {
    try {
        const { name, members } = req.body;
        const group = new Group({
            name,
            creator: req.user._id,
            members: [...members, req.user._id], // Include creator in members
            admins: [req.user._id] // Creator is the first admin
        });
        await group.save();
        
        // Populate group details
        await group.populate('members', 'name email');
        await group.populate('admins', 'name email');
        
        // Notify all members about the new group
        const groupData = {
            id: group._id,
            name: group.name,
            members: group.members,
            admins: group.admins,
            creator: req.user._id
        };
        
        group.members.forEach(member => {
            const memberSocket = Array.from(activeUsers.values())
                .find(u => u.user._id.toString() === member._id.toString())?.socket;
            if (memberSocket) {
                memberSocket.emit('group:created', groupData);
            }
        });

        res.status(201).json(groupData);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get user's groups
app.get('/api/groups', auth, async (req, res) => {
    try {
        const groups = await Group.find({ members: req.user._id })
            .populate('members', 'name email')
            .populate('admins', 'name email')
            .populate('creator', 'name email');
        res.json(groups);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Add members to group
app.post('/api/groups/:groupId/members', auth, async (req, res) => {
    try {
        const { members } = req.body;
        const group = await Group.findById(req.params.groupId);
        
        if (!group) {
            return res.status(404).json({ error: 'Group not found' });
        }
        
        // Check if user is an admin
        if (!group.admins.includes(req.user._id)) {
            return res.status(403).json({ error: 'Only admins can add members' });
        }
        
        // Add new members
        const newMembers = members.filter(m => !group.members.includes(m));
        group.members.push(...newMembers);
        await group.save();
        
        // Populate group details
        await group.populate('members', 'name email');
        await group.populate('admins', 'name email');
        
        // Notify all members about the update
        const groupData = {
            id: group._id,
            name: group.name,
            members: group.members,
            admins: group.admins,
            creator: group.creator
        };
        
        group.members.forEach(member => {
            const memberSocket = Array.from(activeUsers.values())
                .find(u => u.user._id.toString() === member._id.toString())?.socket;
            if (memberSocket) {
                memberSocket.emit('group:updated', groupData);
            }
        });

        res.json(groupData);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Exit group
app.post('/api/groups/:groupId/exit', auth, async (req, res) => {
    try {
        const group = await Group.findById(req.params.groupId);
        
        if (!group) {
            return res.status(404).json({ error: 'Group not found' });
        }

        // Check if user is in the group
        if (!group.members.includes(req.user._id)) {
            return res.status(403).json({ error: 'You are not a member of this group' });
        }

        // Don't allow the creator to exit if they're the only admin
        if (group.creator.toString() === req.user._id.toString() && group.admins.length === 1) {
            return res.status(403).json({ error: 'As the only admin, you cannot exit the group. Transfer admin rights first.' });
        }

        // Remove user from members and admins
        group.members = group.members.filter(id => id.toString() !== req.user._id.toString());
        group.admins = group.admins.filter(id => id.toString() !== req.user._id.toString());

        // If no members left, delete the group
        if (group.members.length === 0) {
            await Group.findByIdAndDelete(req.params.groupId);
            // Delete all messages in the group
            await Message.deleteMany({ group: req.params.groupId });
            res.json({ message: 'Group deleted as it has no members' });
            return;
        }

        await group.save();

        // Notify remaining members about the exit
        const groupData = {
            id: group._id,
            name: group.name,
            members: group.members,
            admins: group.admins,
            creator: group.creator
        };

        group.members.forEach(memberId => {
            const memberSocket = Array.from(activeUsers.values())
                .find(u => u.user._id.toString() === memberId.toString())?.socket;
            if (memberSocket) {
                memberSocket.emit('group:updated', groupData);
            }
        });

        res.json({ message: 'Successfully left the group' });
    } catch (error) {
        console.error('Error exiting group:', error);
        res.status(500).json({ error: error.message });
    }
});

// Socket.IO connection handling
io.on('connection', async (socket) => {
    console.log('User connected:', socket.user.name);
    
    try {
        // Update user's online status in database
        await User.findByIdAndUpdate(socket.userId, { 
            isOnline: true, 
            lastSeen: new Date() 
        });
        
        // Add user to active users
        activeUsers.set(socket.userId, {
            socket,
            user: socket.user
        });

        // Fetch all users with their current online status
        const allUsers = await User.find({}).select('-password');
        const usersList = allUsers.map(u => ({
            id: u._id.toString(),
            name: u.name,
            email: u.email,
            profilePicture: u.profilePicture,
            status: u.status,
            isOnline: activeUsers.has(u._id.toString()) || u.isOnline,
            lastSeen: u.lastSeen,
            isPrivate: u.isPrivate
        }));
        
        // Emit to all connected users
        io.emit('users:update', usersList);
        
        // Broadcast to other users that a new user is online
        socket.broadcast.emit('user:online', {
            userId: socket.userId,
            timestamp: new Date()
        });
    } catch (error) {
        console.error('Error updating online status:', error);
    }

    // Handle private messages with files
    socket.on('private-message', async ({ recipientId, content, fileData }) => {
        try {
            // Check if recipient has a private profile
            const recipient = await User.findById(recipientId);
            if (!recipient) {
                socket.emit('error', { message: 'Recipient not found' });
                return;
            }

            if (recipient.isPrivate) {
                socket.emit('error', { message: 'This user has a private profile and cannot receive messages' });
                return;
            }

            // Create message object
            const messageData = {
                content,
                sender: socket.userId,
                recipient: recipientId,
                timestamp: new Date()
            };

            // Add file data if present
            if (fileData) {
                messageData.fileUrl = fileData.fileUrl;
                messageData.fileName = fileData.fileName;
                messageData.fileType = fileData.type;  // Make sure fileType is included
            }

            // Save message to database
            const message = new Message(messageData);
            await message.save();

            // Populate sender info for the response
            await message.populate('sender', 'name email');

            const formattedMessage = {
                id: message._id,
                content,
                sender: {
                    id: socket.userId,
                    name: socket.user.name
                },
                recipientId,
                timestamp: message.timestamp,
                fileData: fileData ? {
                    url: fileData.fileUrl,
                    fileName: fileData.fileName,
                    type: fileData.type
                } : null
            };

            // Send to recipient if online
            const recipientSocket = Array.from(activeUsers.values())
                .find(u => u.user._id.toString() === recipientId)?.socket;
                
            if (recipientSocket) {
                recipientSocket.emit('private-message', formattedMessage);
            }

            // Send back to sender
            socket.emit('private-message', formattedMessage);
        } catch (error) {
            console.error('Error sending message:', error);
            socket.emit('error', { message: 'Failed to send message' });
        }
    });

    // Handle group messages
    socket.on('group-message', async ({ groupId, content, fileData }) => {
        try {
            const group = await Group.findById(groupId);
            if (!group || !group.members.map(id => id.toString()).includes(socket.userId)) {
                socket.emit('error', { message: 'Not authorized to send messages to this group' });
                return;
            }

            const messageData = {
                content,
                sender: socket.userId,
                group: groupId,
                timestamp: new Date()
            };

            if (fileData) {
                messageData.fileUrl = fileData.fileUrl;
                messageData.fileName = fileData.fileName;
                messageData.fileType = fileData.type;
            }

            const message = new Message(messageData);
            await message.save();
            await message.populate('sender', 'name email');

            const formattedMessage = {
                id: message._id,
                content,
                sender: {
                    id: socket.userId,
                    name: socket.user.name
                },
                groupId: message.group.toString(),
                timestamp: message.timestamp,
                fileData: fileData || null
            };

            // Send to all group members
            group.members.forEach(memberId => {
                const memberSocket = Array.from(activeUsers.values())
                    .find(u => u.user._id.toString() === memberId.toString())?.socket;
                if (memberSocket) {
                    memberSocket.emit('group-message', formattedMessage);
                }
            });
        } catch (error) {
            console.error('Error sending group message:', error);
            socket.emit('error', { message: 'Failed to send message' });
        }
    });

    // WebRTC Signaling
    socket.on('call-user', ({ recipientId, offer, isVideo }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('call-made', {
                callerId: socket.userId,
                callerName: socket.user.name,
                offer: offer,
                isVideo: isVideo
            });
        }
    });

    socket.on('call-accepted', ({ recipientId, answer }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('call-accepted', { answer });
        }
    });

    socket.on('call-rejected', ({ recipientId }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('call-rejected');
        }
    });

    socket.on('call-ended', ({ recipientId }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('call-ended');
        }
    });

    socket.on('ice-candidate', ({ recipientId, candidate }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('ice-candidate', { candidate });
        }
    });

    // Handle typing indicators
    socket.on('typing', ({ recipientId }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('userTyping', socket.user.name);
        }
    });

    socket.on('stopTyping', ({ recipientId }) => {
        const recipient = activeUsers.get(recipientId);
        if (recipient) {
            recipient.socket.emit('userStoppedTyping');
        }
    });

    // Handle heartbeat for presence
    socket.on('heartbeat', async () => {
        try {
            await User.findByIdAndUpdate(socket.userId, { 
                lastSeen: new Date() 
            });
        } catch (error) {
            console.error('Error updating heartbeat:', error);
        }
    });

    socket.on('disconnect', async () => {
        console.log('User disconnected:', socket.user.name);
        
        try {
            // Update user's online status and last seen time in database
            await User.findByIdAndUpdate(socket.userId, { 
                isOnline: false,
                lastSeen: new Date() 
            });
            
            activeUsers.delete(socket.userId);
            
            // Broadcast to all users that this user is offline with timestamp
            io.emit('user:offline', {
                userId: socket.userId,
                timestamp: new Date()
            });

            // Update user list for all connected users
            const users = await User.find({}).select('-password');
            const usersList = users.map(u => ({
                id: u._id.toString(),
                name: u.name,
                email: u.email,
                profilePicture: u.profilePicture,
                status: u.status,
                isOnline: activeUsers.has(u._id.toString()),
                lastSeen: u.lastSeen
            }));
            
            io.emit('users:update', usersList);
        } catch (error) {
            console.error('Error updating offline status:', error);
        }
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});