const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Group = require('../models/Group');
const Message = require('../models/Message');
const auth = require('../middleware/auth');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');

// Configure multer for profile picture uploads
const storage = multer.diskStorage({
    destination: async function (req, file, cb) {
        const uploadDir = path.join(__dirname, '../../public/uploads/profiles');
        try {
            await fs.mkdir(uploadDir, { recursive: true });
            cb(null, uploadDir);
        } catch (error) {
            cb(error);
        }
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'profile-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB limit
    },
    fileFilter: function (req, file, cb) {
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('Only image files are allowed!'));
        }
        cb(null, true);
    }
});

// Get user profile
router.get('/profile', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user._id).select('-password');
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching profile' });
    }
});

// Update user profile
router.put('/profile', auth, async (req, res) => {
    const updates = Object.keys(req.body);
    const allowedUpdates = ['name', 'email', 'status', 'isPrivate'];
    const isValidOperation = updates.every(update => allowedUpdates.includes(update));

    if (!isValidOperation) {
        return res.status(400).json({ error: 'Invalid updates!' });
    }

    try {
        // Check if email is being changed and if it's already in use
        if (req.body.email && req.body.email !== req.user.email) {
            const existingUser = await User.findOne({ email: req.body.email });
            if (existingUser) {
                return res.status(400).json({ error: 'Email already in use' });
            }
        }

        // Check status length
        if (req.body.status && req.body.status.length > 50) {
            return res.status(400).json({ error: 'Status must be 50 characters or less' });
        }

        updates.forEach(update => req.user[update] = req.body[update]);
        await req.user.save();
        
        const userToReturn = req.user.toObject();
        delete userToReturn.password;
        
        res.json(userToReturn);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Change password
router.put('/password', auth, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        // Verify current password
        const isMatch = await bcrypt.compare(currentPassword, req.user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Current password is incorrect' });
        }

        // Update to new password
        req.user.password = newPassword;
        await req.user.save();

        res.json({ message: 'Password updated successfully' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Delete account
router.delete('/profile', auth, async (req, res) => {
    try {
        const userId = req.user._id;

        // Delete profile picture if it's not the default
        if (req.user.profilePicture && !req.user.profilePicture.includes('user-default.jpg')) {
            const picturePath = path.join(__dirname, '../../public', req.user.profilePicture);
            try {
                await fs.remove(picturePath);
            } catch (err) {
                console.error('Error deleting profile picture:', err);
            }
        }

        // Delete all messages sent by or to this user
        await Message.deleteMany({
            $or: [
                { sender: userId },
                { recipient: userId }
            ]
        });

        // Remove user from all groups they're part of
        await Group.updateMany(
            { members: userId },
            { $pull: { members: userId } }
        );

        // Delete empty groups where this user was the only member
        await Group.deleteMany({
            members: { $size: 0 }
        });

        // Finally, delete the user
        await User.findByIdAndDelete(userId);

        res.json({ message: 'Account deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error deleting account' });
    }
});

// Profile picture upload route
router.post('/profile-picture', auth, upload.single('profilePicture'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const profilePicturePath = '/uploads/profiles/' + req.file.filename;
        
        // Delete old profile picture if it exists and is not the default
        if (req.user.profilePicture && !req.user.profilePicture.includes('user-default.jpg')) {
            const oldPicturePath = path.join(__dirname, '../../public', req.user.profilePicture);
            try {
                await fs.remove(oldPicturePath);
            } catch (err) {
                console.error('Error deleting old profile picture:', err);
            }
        }

        // Update user's profile picture
        req.user.profilePicture = profilePicturePath;
        await req.user.save();

        res.json({ 
            message: 'Profile picture updated successfully',
            profilePicture: profilePicturePath
        });
    } catch (error) {
        // Delete uploaded file if there was an error
        if (req.file) {
            const filePath = path.join(__dirname, '../../public/uploads/profiles', req.file.filename);
            try {
                await fs.remove(filePath);
            } catch (err) {
                console.error('Error deleting uploaded file:', err);
            }
        }
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;